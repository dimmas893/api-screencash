import show from "./Show";

export { show }

