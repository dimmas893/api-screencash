import React from 'react'
import App from '../layouts/App'

export default function Home() {
    return (
        <App title="Screencash">
            <div className="container">
                Screencash
            </div>
        </App>
    )
}
